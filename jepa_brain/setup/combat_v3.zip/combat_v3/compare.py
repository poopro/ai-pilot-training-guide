"""Paired development comparison. Training is complete before this runs."""
import os,sys,json,hashlib
from pathlib import Path
from datetime import datetime
from statistics import mean
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT);sys.path.insert(0,str(ROOT))
torch.set_num_threads(1)
from stable_baselines3 import SAC
from combat_v3.env import CombatEnvV3,INFO_KEYS
def compare(bundle,episodes=3,seed=20261110):
    bundle=Path(bundle)
    m=json.loads((bundle/'manifest.json').read_text(encoding='utf-8'))
    if m['format']!='guided_combat_v3':raise ValueError('Only v3 bundles can be compared')
    for name,expected in m['config']['source_sha256'].items():
        if hashlib.sha256((ROOT/'combat_v3'/name).read_bytes()).hexdigest()!=expected:raise ValueError('Source changed: '+name)
    if hashlib.sha256((bundle/'model.zip').read_bytes()).hexdigest()!=m['model_sha256']:raise ValueError('Incomplete model')
    policy=SAC.load(str(bundle/'model.zip'),device='cpu')
    rows=[]
    for opponent in ('easy','maneuver','duel'):
        for ep in range(episodes):
            s=seed+ep
            for label in ('guide','policy'):
                env=CombatEnvV3(opponent=opponent,scenario='official')
                try:
                    obs,_=env.reset(seed=s);reward=0.
                    for n in range(18000):
                        a=np.zeros(4,dtype=np.float32) if label=='guide' else policy.predict(obs,deterministic=True)[0]
                        obs,r,done,truncated,info=env.step(a);reward+=r
                        if done or truncated:break
                    row={'policy':label,'seed':s,'steps':n+1,'reward':reward,**{k:info[k] for k in INFO_KEYS}}
                    rows.append(row)
                    print(f"比較：{opponent} seed={s} {label} -> {info['outcome']}，攻擊 {info['attack_seconds']:.2f} 秒",flush=True)
                finally:env.close()
    summary={}
    for opponent in ('easy','maneuver','duel','all'):
        summary[opponent]={}
        for label in ('guide','policy'):
            group=[r for r in rows if r['policy']==label and (opponent=='all' or r['opponent']==opponent)]
            summary[opponent][label]={key:mean(float(r[key]) for r in group) for key in ('is_kill','own_crash','was_hit','survived','attack_seconds','guard_fraction')}
            summary[opponent][label]['episodes']=len(group)
    safe=all(summary[o]['policy']['own_crash']<=summary[o]['guide']['own_crash'] and
             summary[o]['policy']['was_hit']<=summary[o]['guide']['was_hit'] and
             summary[o]['policy']['is_kill']>=summary[o]['guide']['is_kill'] for o in ('easy','maneuver','duel'))
    improved=summary['all']['policy']['is_kill']>summary['all']['guide']['is_kill']
    decision='candidate_for_independent_host_testing' if safe and improved else 'retain_guide_as_deployment_default'
    out=ROOT/'combat_v3'/'evaluations'/('compare_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    out.mkdir(parents=True)
    report={'bundle':str(bundle),'summary':summary,'decision':decision,'episodes':rows,
       'note':'Small paired development set; not official Host victory. These seeds are no longer an independent holdout after selection.'}
    (out/'comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('比較報告：'+str(out),flush=True)
    print('通過小型開發集比較，下一步仍須獨立測試及官方 Host 驗證。' if safe and improved else
          '尚未顯示比引導器穩定改善；官方連線入口繼續預設純引導器。',flush=True)
    return report
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('bundle',type=Path);p.add_argument('--episodes',type=int,default=3)
    a=p.parse_args()
    if a.episodes<1:p.error('episodes must be positive')
    compare(a.bundle,a.episodes)
