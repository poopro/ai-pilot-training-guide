"""Published rules plus explicitly labeled local score estimates."""
import math,json
from pathlib import Path
SETTINGS=json.loads(Path(__file__).with_name('config.json').read_text(encoding='utf-8'))
FT_TO_M=0.3048
HZ=int(SETTINGS['hz'])
ROUND_STEPS=int(SETTINGS['round_seconds']*HZ)
DISTANCES_FT=tuple(SETTINGS['initial_distances_ft'])
TARGET_FRAMES=int(round(SETTINGS['attack_seconds']*HZ))
def attack_window(distance_m,angle_deg):
    return SETTINGS['attack_min_ft']*FT_TO_M<=distance_m<=SETTINGS['attack_max_ft']*FT_TO_M and 0<=angle_deg<=SETTINGS['attack_angle_deg']
def distance_factor(d):
    if d<150:return .1
    if d<500:return 1.2
    if d<1500:return 1.
    if d<=3000:return .5
    return .1
def position_index(distance_m,nose_angle_deg,enemy_nose_angle_deg):
    # AA is the angle from the enemy tail; true enemy attitude is judge-only.
    aa=180-float(enemy_nose_angle_deg)
    return (max(0,1-abs(nose_angle_deg)/90)+max(0,1-abs(aa)/90))*distance_factor(distance_m)
class LocalJudge:
    def __init__(self,weights):
        self.weights=weights
        self.attack=[0,0];self.over_g=[0,0];self.position=[0.,0.]
    def update(self,geo,g_blue,g_red):
        d=geo['distance_m'];ba=geo['blue_angle_deg'];ra=geo['red_angle_deg']
        self.attack[0]+=int(attack_window(d,ba));self.attack[1]+=int(attack_window(d,ra))
        self.over_g[0]+=int(abs(g_blue)>9);self.over_g[1]+=int(abs(g_red)>9)
        self.position[0]+=position_index(d,ba,ra)
        self.position[1]+=position_index(d,ra,ba)
    def advantages(self):
        w=self.weights
        return [w['attack_time']*self.attack[i]/HZ-w['over_g_time']*self.over_g[i]/HZ+
                w['position']*self.position[i] for i in (0,1)]
    def outcome(self,blue_crash,red_crash):
        if blue_crash and red_crash:return 'mutual_crash'
        if blue_crash:return 'own_crash'
        if red_crash:return 'enemy_crash'
        if self.attack[0]>=TARGET_FRAMES and self.attack[1]>=TARGET_FRAMES:return 'simultaneous_hit'
        if self.attack[0]>=TARGET_FRAMES:return 'kill'
        if self.attack[1]>=TARGET_FRAMES:return 'shot_down'
        return 'ongoing'
    def estimated_winner(self,outcome):
        if outcome in ('kill','enemy_crash'):return 'blue'
        if outcome in ('own_crash','shot_down'):return 'red'
        if outcome=='ongoing':return 'undecided'
        a,b=self.advantages()
        return 'draw' if math.isclose(a,b,abs_tol=1e-8) else ('blue' if a>b else 'red')
