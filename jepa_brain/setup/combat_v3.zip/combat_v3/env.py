"""New experiment. The policy/controller see only OWN20+ENEMY6; judge sees truth."""
import math,json
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import gymnasium as gym
from gymnasium.spaces import Box
from combat_v3.fdm import JsbsimFdm
from combat_v3.controller import FlightController,relative_geometry
from combat_v3.interface import simulator_observation,policy_state,PacketController,geometry_from_observation
from combat_v3.rules import LocalJudge,FT_TO_M,DISTANCES_FT,HZ,ROUND_STEPS,attack_window,position_index
INFO_KEYS=('outcome','is_kill','was_hit','survived','own_crash','enemy_crash','timeout',
 'attack_seconds','enemy_attack_seconds','over_9g_seconds','guard_fraction','min_altitude_m','opponent',
 'mean_residual','position_mean','advantage_blue_estimate','advantage_red_estimate','estimated_winner','spawn_distance_ft','stage','local_win','failure_reason')
class CombatEnvV3(gym.Env):
    def __init__(self,opponent='mixed',scenario='official',safety=True,max_steps=ROUND_STEPS,render_modes=None,config=None):
        if scenario not in ('curriculum','official','wide'):raise ValueError('Unknown scenario')
        super().__init__()
        if opponent not in ('easy','maneuver','duel','mixed'):raise ValueError('Unknown opponent')
        self.opponent_setting=opponent;self.safety=bool(safety);self.max_steps=int(max_steps)
        self.render_modes=render_modes;self.record_file=None;self.dt=1/HZ
        self.action_space=Box(-1.,1.,shape=(4,),dtype=np.float32)
        self.observation_space=Box(-500.,500.,shape=(20,),dtype=np.float32)
        self.scenario=scenario
        self.settings=json.loads((Path(__file__).parent/'config.json').read_text(encoding='utf-8'))
        self.stage=2 if scenario!='curriculum' else 0
        self.residual_sum=0.
    def set_stage(self,stage):
        # Takes effect only at the next reset, not in an ongoing episode.
        self.stage=int(np.clip(stage,0,2))
    def reset(self,seed=None,options=None):
        gym.Env.reset(self,seed=seed);rng=self.np_random
        self.episode_stage=self.stage
        if self.opponent_setting=='mixed':
            probabilities=([.7,.3,0] if self.stage==0 else ([.5,.35,.15] if self.stage==1 else [.35,.3,.35]))
            self.opponent=str(rng.choice(['easy','maneuver','duel'],p=probabilities))
        else:self.opponent=self.opponent_setting
        self.spawn_distance_ft=int((options or {}).get('distance_ft',rng.choice(DISTANCES_FT[:self.stage+1])))
        if self.spawn_distance_ft not in DISTANCES_FT:raise ValueError('Distance must match an official initial distance')
        distance=self.spawn_distance_ft*FT_TO_M
        altitude=float(rng.uniform(*self.settings['initial_altitude_ft']));heading=float(rng.uniform(0,360))
        bearing=heading+180
        blue_heading=heading+float(rng.uniform(-15,15))
        if self.stage>=1:
            bearing=heading+float(rng.uniform(0,360))
            blue_heading=float(rng.uniform(0,360))
        # Initial altitude is shared so 3-D separation is the requested distance.
        # Heading distribution is a documented training choice, not specified in text.
        lat,lon=math.radians(23.060552),math.radians(121.948555)
        blat=lat+math.cos(math.radians(bearing))*distance/6378137
        blon=lon+math.sin(math.radians(bearing))*distance/(6378137*math.cos(lat))
        common={'fdm_ic_h':altitude,'fdm_ic_v':self.settings['initial_speed_kts']}
        self.fdm1=JsbsimFdm(fdm_id=1,fdm_ic_lat=math.degrees(blat),fdm_ic_long=math.degrees(blon),fdm_ic_psi=blue_heading%360,**common)
        self.fdm2=JsbsimFdm(fdm_id=2,fdm_ic_lat=math.degrees(lat),fdm_ic_long=math.degrees(lon),fdm_ic_psi=heading,**common)
        self.packet_controller=PacketController(self.settings,self.safety)
        red_settings=dict(self.settings);red_settings.pop('guidance',None)
        self.red_controller=FlightController(self.settings['safety_floor_m'],red_settings)
        self.red_altitude_m=altitude*FT_TO_M;self.red_turn=float(rng.choice([-1,1]))*(6 if self.opponent=='easy' else 25)
        self.next_turn_time=float(rng.uniform(5,10));self.evade_until=0.;self.evade_turn=float(rng.choice([-1,1]))*45
        self.current_step=0;self.blue_frames=self.red_frames=self.over_g_frames=self.guard_frames=0
        self.residual_sum=0.;self.last_residual=np.zeros(4,dtype=np.float32)
        self.outcome='ongoing';self._record_created=False
        self.judge=LocalJudge(self.settings['reference_score_weights'])
        self.geometry=relative_geometry(self.fdm1,self.fdm2)
        self.min_altitude_m=float(self.fdm1.fdm['position/h-agl-ft'])*FT_TO_M
        self.prev_potential=self._potential(self.geometry)
        return policy_state(simulator_observation(self.fdm1,self.fdm2)),self._info()
    def _info(self):
        f=self.fdm1.fdm
        info={'outcome':self.outcome,'is_kill':int(self.outcome=='kill'),
          'was_hit':int(self.outcome in ('shot_down','simultaneous_hit')),
          'survived':int(self.outcome not in ('own_crash','mutual_crash','shot_down','simultaneous_hit')),
          'own_crash':int(self.outcome in ('own_crash','mutual_crash')),
          'enemy_crash':int(self.outcome in ('enemy_crash','mutual_crash')),
          'timeout':int(self.outcome=='timeout'),'attack_seconds':self.blue_frames*self.dt,
          'enemy_attack_seconds':self.red_frames*self.dt,'over_9g_seconds':self.over_g_frames*self.dt,
          'guard_fraction':self.guard_frames/max(self.current_step,1),'min_altitude_m':self.min_altitude_m,
          'opponent':self.opponent,'distance':self.geometry['distance_m'],
          'blue_angle_deg':self.geometry['blue_angle_deg'],'red_angle_deg':self.geometry['red_angle_deg'],
          'altitude_m':float(f['position/h-sl-ft'])*FT_TO_M,'speed_kts':float(f['velocities/vc-kts']),
          'load_factor':abs(float(f['accelerations/n-pilot-z-norm']))}
        a,b=self.judge.advantages()
        info.update(mean_residual=self.residual_sum/max(self.current_step,1),
          position_mean=self.judge.position[0]/max(self.current_step,1),
          advantage_blue_estimate=a,advantage_red_estimate=b,
          estimated_winner=self.judge.estimated_winner(self.outcome),
          spawn_distance_ft=self.spawn_distance_ft,stage=self.episode_stage)
        winner=self.judge.estimated_winner(self.outcome)
        info.update(local_win=int(winner=='blue'),failure_reason=self.outcome if winner=='red' else 'none')
        return info
    @staticmethod
    def _potential(geo):
        alignment=(1+math.cos(math.radians(geo['blue_angle_deg'])))/2
        range_score=math.exp(-abs(geo['distance_m']-550.)/1000.)
        advantage=(1-math.cos(math.radians(geo['red_angle_deg'])))/2
        return .55*alignment+.3*alignment*range_score+.15*advantage
    def render(self,filepath=None):
        if self.render_modes!='txt':return
        path=Path(filepath or self.record_file or 'combat_v3.acmi');path.parent.mkdir(parents=True,exist_ok=True)
        if not self._record_created:
            path.write_text('FileType=text/acmi/tacview\nFileVersion=2.1\n0,ReferenceTime='+datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')+'\n',encoding='utf-8')
            self._record_created=True
        with path.open('a',encoding='utf-8') as stream:
            stream.write(f'#{self.current_step*self.dt:.3f}\n')
            for oid,plane,color,name in [('A0001',self.fdm1,'Blue','Blue Guided SAC'),('B0001',self.fdm2,'Red','Red '+self.opponent)]:
                pose=plane.getProperty('pose')
                stream.write(f'{oid},T={pose[1]}|{pose[7]}|{pose[2]}|{pose[5]}|{pose[4]}|{pose[3]},Type=Air+FixedWing,Name=F16,Color={color},Pilot={name}\n')
    def close(self):
        self.fdm1=None;self.fdm2=None
    def _red_action(self):
        # The scripted adversary also bases threat detection on the available ICD.
        t=self.current_step*self.dt
        if t>=self.next_turn_time:
            self.red_turn=float(self.np_random.choice([-1,1]))*(6 if self.opponent=='easy' else 30)
            self.next_turn_time=t+float(self.np_random.uniform(6,12))
        if self.opponent in ('easy','maneuver'):
            return self.red_controller.level(self.fdm2,self.red_altitude_m,self.red_turn)[0]
        threat=geometry_from_observation(simulator_observation(self.fdm2,self.fdm1))
        if threat['distance_m']<1200 and threat['aspect_proxy_deg']<10 and t>=self.evade_until:
            self.evade_until=t+4.;self.evade_turn=float(self.np_random.choice([-1,1]))*45.
        if t<self.evade_until:
            return self.red_controller.level(self.fdm2,self.red_altitude_m,self.evade_turn,380)[0]
        return self.red_controller.pursue(self.fdm2,self.fdm1)[0]
    def step(self,action):
        a=np.asarray(action,dtype=np.float32)
        if a.shape!=(4,) or not np.isfinite(a).all():raise ValueError('Four finite residual values required')
        a=np.clip(a,-1,1)
        obs26=simulator_observation(self.fdm1,self.fdm2)
        cmd,guard=self.packet_controller.act(obs26,a)
        self.fdm1.sendAction(cmd);self.fdm2.sendAction(self._red_action())
        self.fdm1.step();self.fdm2.step();self.current_step+=1;self.guard_frames+=int(guard)
        self.residual_sum+=float(np.mean(a*a))
        self.geometry=geo=relative_geometry(self.fdm1,self.fdm2)
        blue_g=float(self.fdm1.fdm['accelerations/n-pilot-z-norm']);red_g=float(self.fdm2.fdm['accelerations/n-pilot-z-norm'])
        self.judge.update(geo,blue_g,red_g)
        self.blue_frames,self.red_frames=self.judge.attack;self.over_g_frames=self.judge.over_g[0]
        ba=float(self.fdm1.fdm['position/h-agl-ft']);ra=float(self.fdm2.fdm['position/h-agl-ft'])
        self.min_altitude_m=min(self.min_altitude_m,ba*FT_TO_M)
        self.outcome=self.judge.outcome(ba<=self.settings['local_crash_threshold_ft'],ra<=self.settings['local_crash_threshold_ft'])
        terminated=self.outcome!='ongoing';truncated=self.current_step>=self.max_steps and not terminated
        if truncated:self.outcome='timeout'
        potential=0. if terminated else self._potential(geo)
        w=self.settings['reward'];bw=attack_window(geo['distance_m'],geo['blue_angle_deg']);rw=attack_window(geo['distance_m'],geo['red_angle_deg'])
        reward=w['progress_scale']*(.999*potential-self.prev_potential)
        reward+=self.dt*(w['attack_per_second']*(int(bw)-int(rw))+
          w['position_per_second']*position_index(geo['distance_m'],geo['blue_angle_deg'],geo['red_angle_deg'])-
          w['residual_per_second']*float(np.mean(a*a))-w['guard_per_second']*int(guard)-
          w['low_altitude_per_second']*max(0,(1500-ba*FT_TO_M)/1500)**2-
          w['over_g_per_second']*int(abs(blue_g)>9))
        if terminated or truncated:
            if self.outcome=='kill':reward+=w['kill_bonus']+(self.settings['round_seconds']-self.current_step/HZ)/100
            elif self.outcome=='enemy_crash':reward+=w['kill_bonus']/2
            elif self.outcome in ('own_crash','shot_down','mutual_crash'):reward-=w['loss_penalty']
            else:
                av=self.judge.advantages();reward+=5*math.tanh((av[0]-av[1])/20000)
        self.prev_potential=potential;self.last_residual=a.copy()
        info=self._info();info.update(guard_active=bool(guard),actual_action=cmd.tolist(),residual=a.tolist())
        obs=policy_state(simulator_observation(self.fdm1,self.fdm2))
        if not np.isfinite(obs).all() or not math.isfinite(reward):raise RuntimeError('Invalid simulation data')
        return obs,float(reward),terminated,truncated,info
