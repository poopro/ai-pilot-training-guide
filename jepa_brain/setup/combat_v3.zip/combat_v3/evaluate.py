"""Fixed-seed evaluation plus ACMI and telemetry; independent of the trainer."""
from __future__ import annotations
import argparse
import csv
import json
import os
import sys
import subprocess
import hashlib
from pathlib import Path
from datetime import datetime
from statistics import mean

ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT);sys.path.insert(0,str(ROOT))
import numpy as np
from stable_baselines3 import SAC
import torch
torch.set_num_threads(1)
from combat_v3.env import CombatEnvV3, INFO_KEYS


def newest_bundle():
    files=list((ROOT/"combat_v3"/"outputs").glob("run_*/final_*/manifest.json"))
    files+=list((ROOT/"combat_v3"/"outputs").glob("run_*/checkpoint_*/manifest.json"))
    if not files:
        raise FileNotFoundError("尚無第三版存檔；先訓練，或加 --guide 測試引導飛控")
    return max(files,key=lambda p:p.stat().st_mtime).parent


def main():
    parser=argparse.ArgumentParser(description="第三版評估與 Tacview")
    parser.add_argument("--bundle",type=Path)
    parser.add_argument("--guide",action="store_true",help="測零修正引導器，不使用模型")
    parser.add_argument("--episodes",type=int,default=5)
    parser.add_argument("--seed",type=int,default=20261110)
    parser.add_argument("--opponent",choices=["easy","maneuver","duel","mixed"],default="mixed")
    parser.add_argument("--scenario",choices=["official","curriculum","wide"],default="official")
    parser.add_argument("--max-steps",type=int,default=18000)
    parser.add_argument("--no-safety",action="store_true")
    parser.add_argument("--acmi",action="store_true")
    parser.add_argument("--open-tacview",action="store_true")
    args=parser.parse_args()
    if args.episodes<=0 or args.max_steps<=0 or (args.guide and args.bundle):
        parser.error("回合／步數必須大於零；guide 與 bundle 擇一")
    bundle=None;model=None
    if not args.guide:
        try:
            bundle=args.bundle or newest_bundle()
            manifest=json.loads((bundle/"manifest.json").read_text(encoding="utf-8"))
            if manifest["format"]!="guided_combat_v3":
                raise ValueError("這是不同動作定義的模型")
            for name in ["env.py","controller.py","interface.py","rules.py","config.json"]:
                actual=hashlib.sha256((ROOT/"combat_v3"/name).read_bytes()).hexdigest()
                if manifest["config"]["source_sha256"].get(name)!=actual:
                    raise ValueError("環境或獎勵已改變，請先還原此模型的設定再評估")
            for name,expected in manifest["config"]["dependency_sha256"].items():
                if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=expected:
                    raise ValueError("模擬相依來源已改變")
            actual=hashlib.sha256((bundle/"model.zip").read_bytes()).hexdigest()
            if actual!=manifest["model_sha256"]:
                raise ValueError("模型校驗不符，可能未完整儲存")
            model=SAC.load(str(bundle/"model.zip"),device="cpu")
        except (OSError,ValueError,KeyError) as e:
            parser.error(str(e))
    out=ROOT/"combat_v3"/"evaluations"/("eval_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    out.mkdir(parents=True)
    env=CombatEnvV3(opponent=args.opponent,scenario=args.scenario,safety=not args.no_safety,
                    max_steps=args.max_steps,render_modes="txt" if args.acmi else None)
    rows=[]
    fields=["time_seconds","altitude_m","speed_kts","load_factor","distance","blue_angle_deg",
            "red_angle_deg","attack_seconds","enemy_attack_seconds","guard_active","mean_residual","position_mean"]
    try:
        for ep in range(1,args.episodes+1):
            seed=args.seed+ep-1
            obs,_=env.reset(seed=seed)
            env.record_file=str(out/f"fight_{ep}.acmi")
            if args.acmi:env.render()
            total=0.0
            with (out/f"telemetry_{ep}.csv").open("w",newline="",encoding="utf-8") as stream:
                writer=csv.DictWriter(stream,fieldnames=fields)
                writer.writeheader()
                for step in range(1,args.max_steps+1):
                    action=np.zeros(4,dtype=np.float32) if args.guide else model.predict(obs,deterministic=True)[0]
                    obs,reward,done,truncated,info=env.step(action)
                    total+=reward
                    if step%6==0 or done or truncated:
                        record={key:info[key] for key in fields if key!="time_seconds"}
                        record["time_seconds"]=step/60.0
                        writer.writerow(record)
                    if args.acmi and (step%3==0 or done or truncated):env.render()
                    if done or truncated:break
            row={"episode":ep,"seed":seed,"steps":step,"reward":round(total,4),
                 **{key:info[key] for key in INFO_KEYS}}
            rows.append(row)
            print(json.dumps(row,ensure_ascii=False),flush=True)
    finally:env.close()
    summary={key:mean(float(row[key]) for row in rows) for key in
             ["is_kill","was_hit","survived","own_crash","attack_seconds","enemy_attack_seconds","guard_fraction"]}
    summary.update({"episodes":args.episodes,"mean_reward":mean(r["reward"] for r in rows),
                    "policy":"guide_only" if args.guide else str(bundle),"scenario":args.scenario,
                    "opponent":args.opponent,"safety":not args.no_safety,
                    "note":"官方公告初始距離／高度／速度；本機裁判與參考權重估計，Host 最終仲裁。"})
    (out/"report.json").write_text(json.dumps({"summary":summary,"episodes":rows},ensure_ascii=False,indent=2),encoding="utf-8")
    print("總結："+json.dumps(summary,ensure_ascii=False),flush=True)
    print(f"評估資料夾：{out}",flush=True)
    if args.open_tacview and args.acmi:
        exe=Path(r"C:\Program Files (x86)\Tacview\Tacview64.exe")
        if exe.is_file():subprocess.Popen([str(exe),str(out/"fight_1.acmi")])
        else:print("找不到 Tacview；請手動開啟 ACMI。")


if __name__=="__main__":
    main()
