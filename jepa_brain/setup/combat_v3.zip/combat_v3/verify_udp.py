"""Loopback fixture: real player subprocess, schema, READY, INIT gating, latency."""
import os,sys,socket,subprocess,json,struct,time,signal
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT);sys.path.insert(0,str(ROOT))
from combat_v3.env import CombatEnvV3
from combat_v3.interface import simulator_observation
def main():
    v=ROOT/'combat_v3'/'verification';v.mkdir(exist_ok=True)
    receive=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);receive.bind(('127.0.0.1',0));receive.settimeout(.15)
    probe=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);probe.bind(('127.0.0.1',0));port=probe.getsockname()[1];probe.close()
    net={'listen_ip':'127.0.0.1','listen_port':port,'host_ip':'127.0.0.1','host_port':receive.getsockname()[1],'max_hz':60}
    path=v/'loopback_network.json';path.write_text(json.dumps(net),encoding='utf-8')
    env=CombatEnvV3(opponent='easy',max_steps=1);env.reset(seed=77)
    obs=simulator_observation(env.fdm1,env.fdm2);env.close()
    log=(v/'loopback_player.log').open('w',encoding='utf-8')
    proc=subprocess.Popen([sys.executable,'-X','utf8',str(ROOT/'combat_v3/player.py'),'--network',str(path),'--guide'],stdout=log,stderr=log)
    send=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    latency=[];commands=[]
    try:
        deadline=time.monotonic()+25
        while time.monotonic()<deadline:
            send.sendto(struct.pack('<26d',*obs),('127.0.0.1',port))
            try:packet,_=receive.recvfrom(4096);break
            except socket.timeout:
                if proc.poll() is not None:raise RuntimeError('Player exited')
        else:raise RuntimeError('Player did not respond')
        for n in range(65):
            time.sleep(.025)
            start=time.perf_counter()
            send.sendto(struct.pack('<26d',*obs),('127.0.0.1',port));packet,_=receive.recvfrom(4096)
            cmd=struct.unpack('<fffff10s',packet);commands.append(cmd)
            assert len(packet)==30 and cmd[-1]==b'PLAYER_CMD'
            assert np.allclose(cmd[:4],[0,0,0,.8],atol=1e-6)
            latency.append((time.perf_counter()-start)*1000)
        assert commands[-1][4]==2
        obs[0]+=.0001
        time.sleep(.025);send.sendto(struct.pack('<26d',*obs),('127.0.0.1',port));p,_=receive.recvfrom(4096)
        command=struct.unpack('<fffff10s',p)
        assert all(-1<=x<=1 for x in command[:3]) and 0<=command[3]<=1 and command[4]==2
        send.sendto(b'bad',('127.0.0.1',port))
        try:receive.recvfrom(4096);raise AssertionError('Invalid OBS was accepted')
        except socket.timeout:pass
        report={'udp_loopback':'passed','packet_bytes':30,'ready_after_initialization':True,
          'init_controller_frozen':True,'invalid_obs_ignored':True,'latency_ms_p95':float(np.percentile(latency,95)),
          'latency_ms_max':max(latency),'official_host':'not tested by this fixture'}
        (v/'udp_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(json.dumps(report),flush=True)
    finally:
        proc.terminate();proc.wait(timeout=10)
        send.close();receive.close();log.close()
if __name__=='__main__':main()
