"""Rate-damped F-16 guidance using the same four legal control channels."""
from __future__ import annotations

import math
import numpy as np

FT_TO_M = 0.3048


def wrap_deg(angle):
    return (float(angle) + 180.0) % 360.0 - 180.0


def relative_geometry(own, enemy):
    """Range and nose-to-LOS angles for both sides (not velocity direction)."""
    earth_radius = 6378137.0
    lat1, lon1, h1 = own.getProperty("position_rad")
    lat2, lon2, h2 = enemy.getProperty("position_rad")
    rel = np.array([(lat2-lat1)*earth_radius,
                    (lon2-lon1)*earth_radius*math.cos((lat1+lat2)/2),
                    -(h2-h1)*FT_TO_M], dtype=float)
    distance = float(np.linalg.norm(rel))

    def angles(fdm, vector):
        psi, theta, phi = fdm.getProperty("attitudeRad")[:3]
        cp, sp = math.cos(phi), math.sin(phi)
        ct, st = math.cos(theta), math.sin(theta)
        cy, sy = math.cos(psi), math.sin(psi)
        rotation = np.array([[ct*cy, ct*sy, -st],
                             [sp*st*cy-cp*sy, sp*st*sy+cp*cy, sp*ct],
                             [cp*st*cy+sp*sy, cp*st*sy-sp*cy, cp*ct]])
        x, y, z = rotation @ vector
        angle = math.degrees(math.acos(float(np.clip(x/max(distance,1e-9),-1,1))))
        return angle, math.degrees(math.atan2(y,x)), math.degrees(math.atan2(-z,math.hypot(x,y)))

    blue_angle, blue_az, blue_el = angles(own, rel)
    red_angle, red_az, red_el = angles(enemy, -rel)
    bearing = math.degrees(math.atan2(rel[1],rel[0])) % 360
    elevation = math.degrees(math.atan2(-rel[2],math.hypot(rel[0],rel[1])))
    return {"distance_m":distance, "blue_angle_deg":blue_angle,
            "red_angle_deg":red_angle, "blue_az_deg":blue_az, "blue_el_deg":blue_el,
            "red_az_deg":red_az, "red_el_deg":red_el,
            "bearing_deg":bearing, "elevation_deg":elevation}


class FlightController:
    """Guidance is deterministic; SAC learns bounded corrections to it."""
    def __init__(self, safety_floor_m=800.0, config=None):
        self.safety_floor_m = float(safety_floor_m)
        self.config = config or {"residual_limits": [8.,2.,.015,15.], "tracking_limits": [2.5,.8,.005,8.]}
        self.last = np.array([0.0,0.0,0.0,0.8], dtype=float)
        self.recovering = False
        self.previous_bearing=None;self.bearing_rate=0.;self.mode='approach'
        self.bank_target=0.;self.pitch_target=0.

    def command(self, plane, roll_deg, pitch_deg, speed_kts, rudder=0.0, safety=True):
        f = plane.fdm
        alt = float(f["position/h-sl-ft"])*FT_TO_M
        downward = float(f["velocities/v-down-fps"])*FT_TO_M
        cas = float(f["velocities/vc-kts"])
        roll = float(f["attitude/phi-deg"])
        pitch = float(f["attitude/theta-deg"])
        alpha = float(f["aero/alpha-deg"])
        guard = False
        # Stay in recovery until a height margin is restored, avoiding mode flicker.
        if safety and (alt < self.safety_floor_m or
                       (downward > 10 and alt/downward < 15.0)):
            self.recovering = True
        if self.recovering and alt > self.safety_floor_m+400 and downward<=0 and cas>220:
            self.recovering = False
        if safety and self.recovering:
            roll_deg, pitch_deg, speed_kts, rudder = 0.0, 12.0, 400.0, 0.0
            guard = True
        if safety and (cas < 180 or alpha > 22):
            roll_deg, pitch_deg, speed_kts, rudder = 0.0, min(pitch,2.0), 420.0, 0.0
            guard = True
        p = math.degrees(float(f["velocities/p-rad_sec"]))
        q = math.degrees(float(f["velocities/q-rad_sec"]))
        bank = min(abs(roll),60.0)
        trim = 0.035/max(math.cos(math.radians(bank)),0.5)
        aileron = 0.025*wrap_deg(roll_deg-roll) - 0.008*p
        elevator = -0.035*(float(pitch_deg)-pitch) + 0.009*q - trim
        throttle = 0.65 + 0.008*(float(speed_kts)-cas)
        if guard:
            throttle = 1.0
        # G limiter uses only the ownship G channel in the official ICD.
        if safety and abs(float(f["accelerations/n-pilot-z-norm"]))>8.5:
            elevator=max(elevator,-.08)
        cmd = np.array([aileron,elevator,rudder,throttle], dtype=float)
        cmd = np.clip(cmd,[-1,-1,-1,0],[1,1,1,1])
        # Rate limits are part of the controller, also used during evaluation.
        delta = np.clip(cmd-self.last,[-.12,-.08,-.06,-.025],[.12,.08,.06,.025])
        self.last = self.last + delta
        return self.last.copy(), guard

    def pursue_observation(self, plane, geo, residual=None, safety=True):
        f=plane.fdm
        settings=self.config.get('guidance')
        if settings:
            distance=geo['distance_m']
            mode='intercept' if distance>settings['lead_min_distance_m'] else 'track'
            bearing=geo.get('lead_bearing_deg',geo['bearing_deg']) if mode=='intercept' else geo['bearing_deg']
            if self.previous_bearing is None or mode!=self.mode:self.bearing_rate=0.
            else:
                rate=np.clip(wrap_deg(bearing-self.previous_bearing)*60,-20,20)
                self.bearing_rate=.85*self.bearing_rate+.15*rate
            self.previous_bearing=bearing;self.mode=mode
            heading_error=wrap_deg(bearing-f['attitude/psi-deg'])
            feedforward=math.degrees(math.atan(geo.get('own_tas_mps',200)*math.radians(self.bearing_rate)/9.80665))
            roll=float(np.clip(settings['heading_gain']*heading_error+feedforward,-settings['bank_limit_deg'],settings['bank_limit_deg']))
            pitch=float(geo.get('lead_elevation_deg',geo['elevation_deg']) if mode=='intercept' else geo['elevation_deg'])
            if mode=='intercept':pitch+=float(f['aero/alpha-deg'])*math.cos(math.radians(float(f['attitude/phi-deg'])))
            desired_close=float(np.clip((distance-settings['range_target_m'])*settings['closure_gain'],-25,90))
            speed=geo.get('enemy_equivalent_cas_kts',360)+desired_close*1.9438444924*geo.get('cas_ratio',.8)
            if abs(heading_error)>45:speed=min(speed,360.)
            speed=float(np.clip(speed,280,460));rudder=0.
        else:
            heading_error=wrap_deg(geo['bearing_deg']-f['attitude/psi-deg'])
            roll=float(np.clip(1.2*heading_error,-60,60))
            pitch=float(np.clip(geo['elevation_deg'],-18,22))
            distance=geo['distance_m'];speed=360.+float(np.clip((distance-550)*.05,-45,60));rudder=0.
        if residual is not None:
            a=np.clip(np.asarray(residual,dtype=float),-1,1)
            limits=self.config["tracking_limits"] if geo["blue_angle_deg"]<10 and distance<1200 else self.config["residual_limits"]
            roll+=a[0]*limits[0];pitch+=a[1]*limits[1]
            rudder=a[2]*limits[2];speed+=a[3]*limits[3]
        self.bank_target=float(np.clip(roll,-75 if settings else -65,75 if settings else 65))
        self.pitch_target=float(np.clip(pitch,-20,25))
        return self.command(plane,self.bank_target,self.pitch_target,np.clip(speed,280,460 if settings else 440),rudder,safety)

    def pursue(self, plane, target, residual=None, safety=True):
        from combat_v3.interface import simulator_observation,geometry_from_observation
        return self.pursue_observation(plane,geometry_from_observation(simulator_observation(plane,target)),residual,safety)

    def level(self, plane, altitude_m, roll_deg=0.0, speed_kts=360.0):
        f = plane.fdm
        alt = float(f["position/h-sl-ft"])*FT_TO_M
        downward = float(f["velocities/v-down-fps"])*FT_TO_M
        alpha = float(f["aero/alpha-deg"])
        pitch = alpha + float(np.clip((altitude_m-alt)*0.018+downward*0.18,-10,12))
        return self.command(plane,roll_deg,np.clip(pitch,-12,20),speed_kts)
