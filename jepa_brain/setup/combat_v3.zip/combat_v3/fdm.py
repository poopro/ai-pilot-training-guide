"""Load the unchanged official FDM wrapper without its training-only package initializer."""
import importlib.util
from pathlib import Path
SOURCE=Path(__file__).resolve().parents[1]/'envs/jsbsimEnv/jsbsimFdm.py'
_spec=importlib.util.spec_from_file_location('_official_fdm_v3',SOURCE)
_module=importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_module)
class JsbsimFdm(_module.JsbsimFdm):
    """Reapply the final IC after position/attitude, with CAS last and no extra tick."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        p=self.param
        for key,value in [('ic/lat-gc-deg',p['fdm_ic_lat']),('ic/long-gc-deg',p['fdm_ic_long']),
                          ('ic/h-sl-ft',p['fdm_ic_h']),('ic/psi-true-deg',p['fdm_ic_psi']),
                          ('ic/theta-deg',p['fdm_ic_theta']),('ic/phi-deg',p['fdm_ic_phi']),
                          ('ic/vc-kts',p['fdm_ic_v'])]:self.fdm[key]=value
        self.fdm.reset_to_initial_conditions(0)
        self.fdm['propulsion/starter_cmd']=1
        self.fdm['propulsion/active_engine']=True
        self.fdm['propulsion/set-running']=-1
        self.nof=0
