import os,sys,unittest,json,struct,time,socket
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT);sys.path.insert(0,str(ROOT))
from combat_v3.env import CombatEnvV3
from combat_v3.interface import *
from combat_v3.rules import *
from combat_v3.player import RoundState

class ComplianceTests(unittest.TestCase):
    def test_rule_boundaries_and_accumulation(self):
        self.assertTrue(attack_window(500*.3048,2))
        self.assertTrue(attack_window(3000*.3048,0))
        self.assertFalse(attack_window(499*.3048,0))
        self.assertFalse(attack_window(3001*.3048,0))
        self.assertFalse(attack_window(600,2.001))
        j=LocalJudge({'attack_time':2000,'over_g_time':1000,'position':10})
        for k in range(180):
            j.update({'distance_m':600,'blue_angle_deg':0,'red_angle_deg':180},1,1)
            if k<179:self.assertEqual(j.outcome(False,False),'ongoing')
        self.assertEqual(j.outcome(False,False),'kill')
        self.assertAlmostEqual(j.advantages()[0],6000+10*180*2)
        self.assertEqual(distance_factor(149.9),.1)
        self.assertEqual(distance_factor(150),1.2)
        self.assertEqual(distance_factor(500),1.)
        self.assertEqual(distance_factor(1500),.5)
        self.assertEqual(distance_factor(3001),.1)
    def test_exact_udp_layout_and_reject_invalid(self):
        obs=np.arange(26,dtype=float);obs[0]=23;obs[1]=121;obs[20]=23;obs[21]=121
        np.testing.assert_array_equal(decode_packet(struct.pack('<26d',*obs)),obs)
        data=encode_command([2,-2,.4,2],2)
        self.assertEqual(len(data),30)
        self.assertEqual(struct.unpack('<fffff10s',data)[-1],b'PLAYER_CMD')
        self.assertEqual(struct.unpack('<fffff10s',data)[:2],(1.,-1.))
        with self.assertRaises(ValueError):decode_packet(b'x'*209)
        obs[18]=np.nan
        with self.assertRaises(ValueError):decode_packet(struct.pack('<26d',*obs))
    def test_no_state_advances_in_initialization(self):
        settings=json.loads((ROOT/'combat_v3/config.json').read_text())
        p=PacketController(settings);r=RoundState()
        o=np.zeros(26);o[[0,20]]=23;o[[1,21]]=121;o[[2,22]]=12000
        for n in range(61):
            state,started,duplicate=r.observe(o)
            action,g=p.act(o,np.ones(4),started)
            np.testing.assert_array_equal(p.control.last,[0,0,0,.8])
            self.assertFalse(started)
        self.assertEqual(state,2)
        o[0]+=.00001;self.assertTrue(r.observe(o)[1])
    def test_training_udp_encoder_controller_match(self):
        e=CombatEnvV3(opponent='easy',max_steps=3)
        try:
            state,_=e.reset(seed=31)
            packet=simulator_observation(e.fdm1,e.fdm2)
            net=decode_packet(struct.pack('<26d',*packet))
            np.testing.assert_allclose(policy_state(net),state,atol=1e-6)
            # At reset two independently initialized shared controllers must agree.
            pc=PacketController(e.settings)
            a=np.array([1,-1,.4,.5],dtype=np.float32)
            expected,guard=pc.act(net,a)
            _,_,_,_,info=e.step(a)
            np.testing.assert_allclose(expected,info['actual_action'],atol=1e-10)
            self.assertEqual(guard,info['guard_active'])
        finally:e.close()
    def test_deterministic_initialization_and_five_minute_limit(self):
        e=CombatEnvV3(opponent='mixed',max_steps=1)
        try:
            state,info=e.reset(seed=4);second,info2=e.reset(seed=4)
            np.testing.assert_array_equal(state,second)
            self.assertEqual(info['spawn_distance_ft'],info2['spawn_distance_ft'])
            for plane in (e.fdm1,e.fdm2):
                self.assertEqual(plane.param['fdm_ic_v'],340)
                self.assertAlmostEqual(plane.fdm['velocities/vc-kts'],340,places=5)
                self.assertTrue(10000<=plane.param['fdm_ic_h']<=20000)
            self.assertIn(info['spawn_distance_ft'],DISTANCES_FT)
            _,_,done,truncated,info=e.step(np.zeros(4))
            self.assertFalse(done);self.assertTrue(truncated)
            self.assertEqual(info['outcome'],'timeout')
            self.assertEqual(ROUND_STEPS/HZ,300)
        finally:e.close()
    def test_actual_initial_speed_and_distance(self):
        e=CombatEnvV3(opponent='maneuver')
        try:
            for distance in DISTANCES_FT:
                for seed in (20261200,20261201,20261202):
                    _,info=e.reset(seed=seed,options={'distance_ft':distance})
                    self.assertAlmostEqual(info['distance']/.3048,distance,delta=.1)
                    for plane in (e.fdm1,e.fdm2):
                        self.assertAlmostEqual(plane.fdm['velocities/vc-kts'],340,places=5)
                        self.assertEqual(plane.fdm.get_sim_time(),0)
        finally:e.close()
    def test_no_hidden_information_and_bounded_corrections(self):
        cfg=json.loads((ROOT/'combat_v3/config.json').read_text())
        from combat_v3.controller import FlightController
        class Capture(FlightController):
            def command(self,plane,roll,pitch,speed,rudder=0,safety=True):
                return np.array([roll,pitch,rudder,speed]),False
        o=np.zeros(26);o[[0,20]]=23;o[[1,21]]=121;o[[2,22]]=12000
        o[3:6]=0;o[12]=340/FPS_TO_KTS
        snapshot=OwnSnapshot(o)
        with self.assertRaises(KeyError):snapshot.fdm['position/h-agl-ft']
        g={'bearing_deg':0,'elevation_deg':0,'distance_m':550,'blue_angle_deg':30}
        a,_=Capture(800,cfg).pursue_observation(snapshot,g,[1,1,1,1])
        b,_=Capture(800,cfg).pursue_observation(snapshot,g,[0,0,0,0])
        np.testing.assert_allclose(a-b,cfg['residual_limits'])
        g['blue_angle_deg']=5
        a,_=Capture(800,cfg).pursue_observation(snapshot,g,[1,1,1,1])
        b,_=Capture(800,cfg).pursue_observation(snapshot,g,[0,0,0,0])
        np.testing.assert_allclose(a-b,cfg['tracking_limits'])
    def test_curriculum_applies_on_reset(self):
        e=CombatEnvV3(opponent='mixed',scenario='curriculum',max_steps=1)
        try:
            _,old=e.reset(seed=8);e.set_stage(2)
            self.assertEqual(e._info()['stage'],old['stage'])
            _,new=e.reset(seed=8);self.assertEqual(new['stage'],2)
        finally:e.close()
if __name__=='__main__':unittest.main(verbosity=2)
